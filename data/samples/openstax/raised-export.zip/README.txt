Raised export. Every file is a draft for transcriber review, not a certified transcription.
Per figure: -chart.png original crop, .csv checked data, -tactile.pdf/.svg tactile graphic,
.brf braille text, .wav sound mapping, figures.json descriptions and provenance.
